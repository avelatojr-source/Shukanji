# Manual OBS verification checklist

Automated tests exercise the OBS client against a **mock** WebSocket server.
They do **not** prove behaviour against a real OBS install. Work through the
following with a real OBS Studio 28+ before relying on the OBS path.

For each step, note the observed result. Do not mark a step as passing based on
the mock-server test suite.

## 0. Setup
- [ ] OBS Studio 28 or newer installed.
- [ ] Tools → WebSocket Server Settings → Enable WebSocket server.
- [ ] Note the port (default 4455) and whether authentication is enabled.

## 1. Connect — no password
- [ ] Authentication disabled in OBS.
- [ ] App: enter `127.0.0.1` + port, leave password empty, click **Connect**.
- [ ] Expected: status becomes “Connected” with the WebSocket version shown.

## 2. Connect — password enabled
- [ ] Authentication enabled in OBS with a password.
- [ ] App: enter the password, click **Connect**.
- [ ] Expected: “Connected”.
- [ ] Enter a **wrong** password and connect again.
- [ ] Expected: connection fails with an error; no crash.

## 3. Remember password
- [ ] Tick **Remember securely**, connect with a password.
- [ ] Restart the app → click **Connect (saved password)**.
- [ ] Expected: connects without re-typing the password.
- [ ] Confirm the password is **not** present in `%APPDATA%\TikTokStreamTool\config.toml`.

## 4. OBS disconnected
- [ ] Close OBS while the app shows “Connected”.
- [ ] Expected: app shows disconnected/reconnecting; credentials remain available to copy.
- [ ] Reopen OBS → expected: app reconnects automatically (backoff/jitter).

## 5. Output inactive — apply
- [ ] Ensure OBS is **not** streaming/recording.
- [ ] Provide credentials (Streamlabs or manual), click **Apply settings to OBS**.
- [ ] Expected: “OBS settings applied and confirmed.”
- [ ] In OBS: Settings → Stream → Service is **Custom…**, with the correct
      Server URL and Stream Key.

## 6. Output active — refuse
- [ ] Start streaming in OBS manually.
- [ ] Click **Apply settings to OBS** in the app.
- [ ] Expected: refusal — “Refused: OBS output is running.” OBS settings are unchanged.

## 7. Read-back mismatch
- [ ] This is hard to force manually; if you can make OBS report different
      settings than were written, confirm the app shows a mismatch and does
      **not** claim success. The mismatch detail must not contain the stream key.

## 8. Explicit start / stop
- [ ] Click **Start OBS output** once → expected: it asks for confirmation, then
      starts streaming in OBS.
- [ ] Expected status: “OBS output is running — TikTok broadcast status is unknown.”
- [ ] Click **Stop OBS output** (with confirmation) → expected: OBS stops.

## 9. Viewport / scaling
- [ ] Test at 100%, 125%, and 150% Windows display scaling.
- [ ] Check the window at 920×620 and larger; no clipped or unreachable controls.

## Report
Record the OBS version, WebSocket version, and the pass/fail of each step in the
implementation report or a follow-up issue.
