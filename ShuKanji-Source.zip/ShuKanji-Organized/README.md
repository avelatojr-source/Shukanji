# ShuKanji

**A native Windows desktop companion for TikTok LIVE streaming.** ShuKanji retrieves stream credentials through Streamlabs, configures and verifies OBS Studio over OBS WebSocket, can start or stop OBS output, and provides a live activity feed for TikTok chat and audience events.

The repository contains the desktop application and the Rust library it uses for TikTok LIVE event monitoring. The desktop binary is named `shukanji.exe`.

## What it does

### Stream setup and OBS control

- Signs in to Streamlabs through a browser-based OAuth PKCE flow, accepts a pasted token, and offers an opt-in, read-only local token scan.
- Retrieves the RTMP server URL and stream key from Streamlabs, or accepts manual RTMP details.
- Connects to OBS Studio through OBS WebSocket 5.x, reads the current stream status, applies custom RTMP settings, and reads them back to verify the update.
- Starts and stops OBS output only through an explicit user action.
- Reconnects with backoff and checks the actual OBS state again after reconnecting.

### TikTok LIVE monitor

- Connects to a TikTok LIVE by username and displays chat, joins, follows, shares, likes, gifts, and viewer information in one chronological feed.
- De-duplicates combo-gift streak updates and accumulates gift diamond totals from event deltas.
- Coalesces high-volume likes to keep the activity feed readable.
- Caches avatars, gift artwork, custom emotes, and emoji images locally.

The monitor is separate from the Streamlabs credential workflow: it does not require Streamlabs sign-in. ShuKanji reads the stream; it does **not** send chat messages.

## Important status distinctions

A retrieved stream key is not proof that TikTok has accepted a broadcast. ShuKanji distinguishes between credentials being retrieved, OBS settings being applied and verified, OBS output running, and TikTok broadcast status. In particular, **OBS output running does not by itself verify that the TikTok LIVE is active**.

## Requirements

- Windows 10 or Windows 11 (64-bit; primary and supported target in this source tree).
- OBS Studio 28 or later, with the OBS WebSocket server enabled. The default OBS WebSocket port is `4455`.
- A Streamlabs account linked to TikTok for the managed credential-retrieval workflow. Manual RTMP entry is also available.
- Rust 1.85 or later to build the app (edition 2024; see `app/Cargo.toml`).

The app is packaged as a single executable with its fonts, icons, and mascot assets embedded. It does not need an installer. Network access is still needed for Streamlabs, TikTok LIVE monitoring, and remote images.

## Build and run

The repository is intentionally **not** a Cargo workspace. The desktop app is its own crate and uses the adjacent `live-rs/` directory as a local path dependency. Keep both directories at the repository root.

```powershell
cd app
cargo build --release
.\target\release\shukanji.exe
```

Useful development checks, run from `app/`:

```powershell
cargo fmt --check
cargo test --all-targets
cargo clippy --all-targets --all-features -- -D warnings
```

The `live-rs` library can also be checked independently:

```powershell
cd ..\live-rs
cargo test
```

Some capture-replay tests in `live-rs` use the separate `PirateTok/live-testdata` repository; see [`live-rs/README.md`](live-rs/README.md) for its optional setup.

## Repository layout

```text
ShuKanji/
├── README.md                  # This project overview and entry point
├── LICENSE                   # MIT license for the ShuKanji desktop app
├── .gitignore                # Repository-wide build/output/local-file exclusions
├── app/                       # ShuKanji Windows GUI application (Rust/egui)
│   ├── Cargo.toml
│   ├── Cargo.lock              # App dependency lockfile
│   ├── build.rs                # Windows icon and executable metadata
│   ├── assets/                 # App icon, fonts, SVG icons, mascot sprites
│   ├── src/
│   ├── tests/
│   └── README.md               # App-specific build, behavior, and security notes
├── live-rs/                    # Local PirateTok TikTok LIVE client crate
│   ├── Cargo.toml
│   ├── src/                    # HTTP, WebSocket, protobuf decoding, helpers
│   ├── examples/
│   ├── tests/
│   ├── docs/API.md
│   └── LICENSE                 # Separate 0BSD license for this component
└── docs/
    └── MANUAL_OBS_CHECKLIST.md # Real-OBS verification steps
```

### Application architecture

The desktop app uses a layered structure. See the more detailed [architecture notes](docs/ARCHITECTURE.md) for component responsibilities and event flow:

- `app/src/ui/` and `app/src/app.rs` — egui screens, panels, widgets, theme, image cache, and app state.
- `app/src/application/` — command coordinator and event plumbing between the UI and integrations.
- `app/src/domain/` — core models, events, commands, monitor data, errors, and state transitions.
- `app/src/integrations/streamlabs/` — Streamlabs HTTP client, OAuth/PKCE flow, and opt-in local token scan.
- `app/src/integrations/obs/` — OBS WebSocket client, protocol/authentication, and settings synchronization/verification.
- `app/src/integrations/tiktok_live/` — adapter from `live-rs` events into the app's monitor/feed model.
- `app/src/platform/credentials/` — operating-system credential-store abstraction.
- `app/src/persistence/` — non-secret TOML preferences and per-user paths.
- `app/src/diagnostics/` — logging and secret redaction.

The `live-rs/` crate is a separate local dependency. It resolves TikTok room information, opens the WebSocket stream, sends heartbeats, decodes protobuf events, and manages reconnect behavior. The app adapter then coalesces selected event types before they reach the UI.

## Configuration and security

On Windows, the app stores its non-secret settings, logs, and image cache below:

```text
%APPDATA%\TikTokStreamTool\
```

The existing `TikTokStreamTool` directory name is retained by the code; changing it would affect where previous installations' settings and cache are found.

- Streamlabs tokens and OBS passwords are stored through the Windows Credential Manager integration. The app documents no plaintext fallback.
- The TOML configuration stores non-secret stream and OBS preferences, not tokens, passwords, or stream keys.
- Streamlabs token scanning is opt-in and read-only.
- Logs use secret redaction; the OAuth authorization code and PKCE verifier are not logged.

**Compatibility caveat:** the Streamlabs endpoints used by the app are undocumented internal endpoints, not a stable public API. Their continued behavior and acceptance of the app's User-Agent are external compatibility risks. See [`app/README.md`](app/README.md) for the detailed notes.

## Testing and live verification

Automated tests cover app logic, Streamlabs callback/client behavior, OBS protocol/client behavior through mocks, and TikTok monitor event handling. Automated OBS tests use a mock server; complete the [manual OBS checklist](docs/MANUAL_OBS_CHECKLIST.md) against a real OBS installation before relying on an actual broadcast workflow.

The app README documents which live-service behaviors have been exercised and which visual cases (such as specific gift artwork or custom emotes) still need a suitable live event to verify.

## Versioning and releases

The supplied app manifest currently declares version **`0.1.0`** (`app/Cargo.toml`), and the app README labels its feature set `0.1.0`. The included `live-rs` crate independently declares version `0.5.0`. Before publishing a GitHub release tagged `v1.0`, decide whether the desktop app is moving to `1.0.0` and update the app manifest, lockfile, and release notes together. Do not assume the Git tag updates Cargo package metadata.

Build the Windows executable from `app/` using `cargo build --release`. Keep generated `target/` output and release packaging such as `dist/` out of Git; attach the built `shukanji.exe` (or a ZIP containing it and its user guide) to the GitHub Release instead. See [`docs/RELEASING.md`](docs/RELEASING.md).

## Scope and non-goals

ShuKanji is a Windows desktop companion for this workflow, not a general-purpose streaming suite. The current app documentation lists chat sending, overlays, scripting/plugins, multi-account support, global hotkeys, stream history, Discord webhooks, a local REST API, an auto-updater, and macOS/Linux builds as out of scope.

## Licenses

- The ShuKanji desktop application in `app/` is declared **MIT** in `app/Cargo.toml`; the repository-root `LICENSE` contains that license.
- The included `live-rs/` component is separately declared **0BSD** and retains its own `live-rs/LICENSE` and upstream attribution.

Read the applicable license before redistributing or modifying either component.
